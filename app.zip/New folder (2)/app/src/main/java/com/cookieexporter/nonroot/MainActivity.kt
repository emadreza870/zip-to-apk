package com.cookieexporter.nonroot

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.webkit.CookieManager
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.cookieexporter.nonroot.databinding.ActivityMainBinding
import com.cookieexporter.nonroot.model.Cookie
import com.cookieexporter.nonroot.model.CookieList
import com.google.gson.GsonBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var webView: WebView
    private val cookieManager = CookieManager.getInstance()
    
    // لیست کوکی‌های استخراج شده
    private val extractedCookies = mutableListOf<Cookie>()
    
    // آدرس وبسایت برای بارگذاری و استخراج کوکی‌ها
    private var currentUrl = "https://www.google.com"
    
    // ثبت‌کننده درخواست مجوز
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.all { it.value }
        if (allGranted) {
            startExtraction()
        } else {
            showToast("دسترسی‌های لازم اعطا نشد. بدون دسترسی نمی‌توان فایل ذخیره کرد.")
            binding.btnExport.isEnabled = true
        }
    }
    
    // ثبت‌کننده درخواست مدیریت تمام فایل‌ها (برای اندروید 11+)
    private val manageStorageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                startExtraction()
            } else {
                showToast("دسترسی مدیریت فایل اعطا نشد.")
                binding.btnExport.isEnabled = true
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupWebView()
        setupClickListeners()
        updateStatus("آماده به کار - مرورگر داخلی بارگذاری شد")
    }
    
    private fun setupWebView() {
        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mixedContentMode = WebView.MIXED_CONTENT_ALWAYS_ALLOW
        }
        
        // کوکی‌ها به صورت خودکار توسط WebView مدیریت می‌شوند
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)
        
        // بارگذاری صفحه پیش‌فرض
        webView.loadUrl(currentUrl)
        
        // اضافه کردن WebView به layout (مخفی)
        binding.webviewContainer.addView(webView)
    }
    
    private fun setupClickListeners() {
        binding.btnExport.setOnClickListener {
            if (checkAndRequestPermissions()) {
                startExtraction()
            }
        }
        
        binding.btnLoadUrl.setOnClickListener {
            val url = binding.etUrl.text.toString().trim()
            if (url.isNotEmpty()) {
                loadUrl(url)
            } else {
                showToast("لطفاً آدرس وبسایت را وارد کنید")
            }
        }
        
        binding.btnClearCookies.setOnClickListener {
            clearAllCookies()
        }
    }
    
    private fun checkAndRequestPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // اندروید 11 و بالاتر - نیاز به مدیریت تمام فایل‌ها
            if (!Environment.isExternalStorageManager()) {
                showManageStorageRequest()
                false
            } else {
                true
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // اندروید 13 و بالاتر - مجوزهای جدید
            val permissions = arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            
            val notGranted = permissions.filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }
            
            if (notGranted.isNotEmpty()) {
                requestPermissionLauncher.launch(permissions)
                false
            } else {
                true
            }
        } else {
            // اندروید 10 و پایین‌تر
            val writePermission = Manifest.permission.WRITE_EXTERNAL_STORAGE
            if (ContextCompat.checkSelfPermission(this, writePermission) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(arrayOf(writePermission))
                false
            } else {
                true
            }
        }
    }
    
    private fun showManageStorageRequest() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:$packageName")
                manageStorageLauncher.launch(intent)
            } catch (e: Exception) {
                val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                manageStorageLauncher.launch(intent)
            }
        }
    }
    
    private fun startExtraction() {
        binding.btnExport.isEnabled = false
        updateStatus("در حال استخراج کوکی‌ها...")
        
        lifecycleScope.launch {
            val cookies = extractCookiesFromWebView()
            
            if (cookies.isEmpty()) {
                withContext(Dispatchers.Main) {
                    showToast("هیچ کوکی‌ای یافت نشد!")
                    updateStatus("کوکی‌ای یافت نشد - لطفاً ابتدا وارد سایت شوید")
                    binding.btnExport.isEnabled = true
                }
                return@launch
            }
            
            extractedCookies.clear()
            extractedCookies.addAll(cookies)
            
            withContext(Dispatchers.Main) {
                updateStatus("${cookies.size} کوکی یافت شد - در حال ذخیره...")
                saveCookiesToFile(cookies)
            }
        }
    }
    
    private suspend fun extractCookiesFromWebView(): List<Cookie> = withContext(Dispatchers.Main) {
        val cookies = mutableListOf<Cookie>()
        
        // دریافت کوکی‌ها از CookieManager
        val url = webView.url ?: currentUrl
        val host = Uri.parse(url).host ?: ""
        
        // دریافت تمام کوکی‌ها برای دامنه فعلی
        val cookieString = cookieManager.getCookie(url)
        
        if (!cookieString.isNullOrEmpty()) {
            // تجزیه رشته کوکی‌ها
            val cookiePairs = cookieString.split(";")
            
            for (pair in cookiePairs) {
                val parts = pair.trim().split("=", limit = 2)
                if (parts.size == 2) {
                    val name = parts[0].trim()
                    val value = parts[1].trim()
                    
                    // دریافت اطلاعات اضافی کوکی
                    val isSecure = cookieString.contains("secure", ignoreCase = true)
                    val isHttpOnly = cookieString.contains("httponly", ignoreCase = true)
                    
                    cookies.add(
                        Cookie(
                            domain = if (host.startsWith("www.")) host.substring(4) else host,
                            name = name,
                            value = value,
                            path = "/",
                            secure = isSecure,
                            httpOnly = isHttpOnly,
                            session = true,
                            hostOnly = true
                        )
                    )
                }
            }
        }
        
        // روش جایگزین: استفاده از JavaScript برای استخراج کوکی‌ها
        if (cookies.isEmpty()) {
            try {
                val jsResult = executeJavaScript("document.cookie")
                if (!jsResult.isNullOrEmpty()) {
                    val cookiePairs = jsResult.split(";")
                    for (pair in cookiePairs) {
                        val parts = pair.trim().split("=", limit = 2)
                        if (parts.size == 2) {
                            cookies.add(
                                Cookie(
                                    domain = host,
                                    name = parts[0].trim(),
                                    value = parts[1].trim(),
                                    path = "/",
                                    session = true,
                                    hostOnly = true
                                )
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        
        cookies
    }
    
    private suspend fun executeJavaScript(js: String): String? = withContext(Dispatchers.Main) {
        return@withContext try {
            var result: String? = null
            val latch = java.util.concurrent.CountDownLatch(1)
            
            webView.evaluateJavascript("(function() { return ${js}; })();") { value ->
                result = value?.replace("\"", "")?.replace("\\\"", "\"")
                latch.countDown()
            }
            
            latch.await(5, java.util.concurrent.TimeUnit.SECONDS)
            result
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
    
    private fun saveCookiesToFile(cookies: List<Cookie>) {
        lifecycleScope.launch {
            try {
                val cookieList = CookieList(cookies = cookies)
                val gson = GsonBuilder().setPrettyPrinting().create()
                val json = gson.toJson(cookieList)
                
                // ایجاد فایل در پوشه Downloads
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val fileName = "cookies_export_${timestamp}.json"
                val file = File(downloadsDir, fileName)
                
                // نوشتن فایل JSON
                withContext(Dispatchers.IO) {
                    FileWriter(file).use { writer ->
                        writer.write(json)
                    }
                }
                
                updateStatus("فایل با موفقیت ذخیره شد: ${file.name}")
                showToast("فایل کوکی‌ها ذخیره شد!")
                
                // نمایش گزینه‌های اشتراک‌گذاری
                shareFile(file)
                
            } catch (e: Exception) {
                e.printStackTrace()
                updateStatus("خطا در ذخیره فایل: ${e.message}")
                showToast("خطا در ذخیره فایل")
            } finally {
                binding.btnExport.isEnabled = true
            }
        }
    }
    
    private fun shareFile(file: File) {
        try {
            val uri = FileProvider.getUriForFile(
                this,
                "${packageName}.fileprovider",
                file
            )
            
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "کوکی‌های استخراج شده")
                putExtra(Intent.EXTRA_TEXT, "فایل کوکی‌های استخراج شده از طریق Cookie Exporter")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            
            startActivity(Intent.createChooser(shareIntent, "اشتراک‌گذاری فایل کوکی"))
        } catch (e: Exception) {
            e.printStackTrace()
            showToast("خطا در اشتراک‌گذاری فایل")
        }
    }
    
    private fun loadUrl(url: String) {
        var finalUrl = url
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            finalUrl = "https://$url"
        }
        
        webView.loadUrl(finalUrl)
        updateStatus("در حال بارگذاری: $finalUrl")
        binding.etUrl.setText(finalUrl)
        currentUrl = finalUrl
    }
    
    private fun clearAllCookies() {
        lifecycleScope.launch {
            withContext(Dispatchers.Main) {
                cookieManager.removeAllCookies { }
                cookieManager.flush()
                extractedCookies.clear()
                showToast("تمام کوکی‌ها پاک شدند")
                updateStatus("کوکی‌ها پاک شدند - آماده بارگذاری جدید")
            }
        }
    }
    
    private fun updateStatus(message: String) {
        runOnUiThread {
            binding.tvStatus.text = message
        }
    }
    
    private fun showToast(message: String) {
        runOnUiThread {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onDestroy() {
        try {
            binding.webviewContainer.removeView(webView)
            webView.destroy()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onDestroy()
    }
}
