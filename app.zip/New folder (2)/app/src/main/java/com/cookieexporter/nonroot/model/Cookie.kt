package com.cookieexporter.nonroot.model

import com.google.gson.annotations.SerializedName

/**
 * مدل داده‌ای برای کوکی - سازگار با فرمت EditThisCookie و اکستنشن‌های مرورگر
 */
data class Cookie(
    @SerializedName("domain") val domain: String,
    @SerializedName("name") val name: String,
    @SerializedName("value") val value: String,
    @SerializedName("path") val path: String = "/",
    @SerializedName("expirationDate") val expirationDate: Long? = null,
    @SerializedName("httpOnly") val httpOnly: Boolean = false,
    @SerializedName("secure") val secure: Boolean = false,
    @SerializedName("session") val session: Boolean = true,
    @SerializedName("hostOnly") val hostOnly: Boolean = false
)

/**
 * مدل داده‌ای برای لیست کوکی‌ها - خروجی JSON نهایی
 */
data class CookieList(
    @SerializedName("cookies") val cookies: List<Cookie>,
    @SerializedName("count") val count: Int = cookies.size,
    @SerializedName("exportedAt") val exportedAt: String = System.currentTimeMillis().toString()
)
